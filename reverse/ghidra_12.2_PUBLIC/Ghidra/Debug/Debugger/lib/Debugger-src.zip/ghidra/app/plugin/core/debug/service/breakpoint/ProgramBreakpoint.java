/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.app.plugin.core.debug.service.breakpoint;

import java.util.*;
import java.util.stream.Collectors;

import com.google.gson.*;

import db.Transaction;
import ghidra.debug.api.breakpoint.LogicalBreakpoint;
import ghidra.debug.api.breakpoint.LogicalBreakpoint.ProgramMode;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.listing.*;
import ghidra.program.util.ProgramLocation;
import ghidra.trace.model.breakpoint.TraceBreakpointKind;
import ghidra.trace.model.breakpoint.TraceBreakpointKind.CommonSet;
import ghidra.trace.model.breakpoint.TraceBreakpointKind.TraceBreakpointKindSet;
import ghidra.util.Msg;
import ghidra.util.exception.CancelledException;
import ghidra.util.task.TaskMonitor;

/**
 * The static side of a mapped logical breakpoint
 * 
 * <p>
 * Programs don't have a built-in concept of breakpoints, so we store them as breakpoints with a
 * specific type for each state. We also encode other intrinsic properties (length and kinds) to the
 * category. Extrinsic properties (name and sleigh) are encoded in the comment. Because traces are
 * fairly ephemeral, the program bookmarks are the primary means a user has to save and manage a
 * breakpoint set.
 */
public class ProgramBreakpoint {
	private static final Gson GSON = new GsonBuilder().create();

	/**
	 * A class for (de)serializing breakpoint properties in the bookmark's comments
	 */
	static class BreakpointProperties {
		public String name;
		public String sleigh;

		public BreakpointProperties(String name, String sleigh) {
			this.name = name;
			this.sleigh = sleigh;
		}
	}

	/**
	 * Get the kinds of a breakpoint from its bookmark
	 * 
	 * @param mark the bookmark representing a breakpoint
	 * @return the kinds
	 */
	public static Set<TraceBreakpointKind> kindsFromBookmark(Bookmark mark) {
		String[] parts = mark.getCategory().split(";");
		Set<TraceBreakpointKind> result = TraceBreakpointKindSet.decode(parts[0], false);
		if (result.isEmpty()) {
			Msg.warn(TraceBreakpointKind.class,
				"Decoded empty set of kinds from bookmark. Assuming %s".formatted(CommonSet.SWX));
			return CommonSet.SWX.kinds();
		}
		return result;
	}

	/**
	 * Get the length of a breakpoint from its bookmark
	 * 
	 * @param mark the bookmark representing a breakpoint
	 * @return the length in bytes
	 */
	public static long lengthFromBookmark(Bookmark mark) {
		String[] parts = mark.getCategory().split(";");
		if (parts.length < 2) {
			Msg.warn(DebuggerLogicalBreakpointServicePlugin.class,
				"No length for bookmark breakpoint. Assuming 1.");
			return 1;
		}
		try {
			long length = Long.parseLong(parts[1]);
			if (length <= 0) {
				Msg.warn(DebuggerLogicalBreakpointServicePlugin.class,
					"Non-positive length for bookmark breakpoint? Using 1.");
				return 1;
			}
			return length;
		}
		catch (NumberFormatException e) {
			Msg.warn(DebuggerLogicalBreakpointServicePlugin.class,
				"Ill-formatted bookmark breakpoint length: " + e + ". Using 1.");
			return 1;
		}
	}

	/**
	 * Produce a breakpoint from its bookmark (utility).
	 * <p>
	 * The breakpoint manager does not ordinarily use this, as the path to total construction spans
	 * discovering and indexing of logical breakpoints, and then adding into them information
	 * available from program bookmarks and trace breakpoints. This utility eases the processing of
	 * program-specified bookmarks without depending on the breakpoint service.
	 * 
	 * @param program the program containing the bookmark
	 * @param bm the bookmark describing the breakpoint
	 * @return the breakpoint
	 */
	public static ProgramBreakpoint fromBookmark(Program program, Bookmark bm) {
		ProgramBreakpoint brk = new ProgramBreakpoint(program,
			bm.getAddress(), lengthFromBookmark(bm), kindsFromBookmark(bm));
		brk.add(bm);
		return brk;
	}

	private final Program program;
	private final Address address;
	private final ProgramLocation location;
	private final long length;
	private final Set<TraceBreakpointKind> kinds;

	private Bookmark eBookmark; // when present
	private Bookmark dBookmark; // when present

	private String name;
	private String sleigh;

	/**
	 * Construct a program breakpoint
	 * 
	 * @param program the program
	 * @param address the static address of the breakpoint (even if a bookmark is not present there)
	 * @param length the length of the breakpoint in bytes
	 * @param kinds the kinds of the breakpoint
	 */
	public ProgramBreakpoint(Program program, Address address, long length,
			Set<TraceBreakpointKind> kinds) {
		this.program = program;
		this.address = address;
		this.location = new ProgramLocation(program, address);
		this.length = length;
		this.kinds = kinds;
	}

	@Override
	public String toString() {
		// volatile reads
		Bookmark eBookmark = this.eBookmark;
		Bookmark dBookmark = this.dBookmark;
		if (eBookmark != null) {
			return String.format("<enabled %s(%s) at %s in %s>", eBookmark.getTypeString(),
				eBookmark.getCategory(), eBookmark.getAddress(), program.getName());
		}
		else if (dBookmark != null) {
			return String.format("<disabled %s(%s) at %s in %s>", dBookmark.getTypeString(),
				dBookmark.getCategory(), dBookmark.getAddress(), program.getName());
		}
		else {
			return String.format("<absent at %s in %s>", address, program.getName());
		}
	}

	/**
	 * Get the breakpoint's static program location
	 * 
	 * @return the location
	 */
	public ProgramLocation getLocation() {
		return location;
	}

	private void syncProperties(Bookmark bookmark) {
		if (bookmark == null) {
			name = "";
			sleigh = null;
			return;
		}
		String comment = bookmark.getComment();
		if (comment == null || !comment.startsWith("{")) {
			// Backward compatibility.
			name = comment;
			sleigh = null;
			return;
		}
		try {
			BreakpointProperties props = GSON.fromJson(comment, BreakpointProperties.class);
			name = props.name;
			sleigh = props.sleigh;
			return;
		}
		catch (JsonSyntaxException e) {
			Msg.error(this, "Could not parse breakpoint bookmark properties", e);
			name = "";
			sleigh = null;
			return;
		}
	}

	private String computeComment() {
		if ((name == null || "".equals(name)) && (sleigh == null || "".equals(sleigh))) {
			return null;
		}
		return GSON.toJson(new BreakpointProperties(name, sleigh));
	}

	private void writeProperties(Bookmark bookmark) {
		try (Transaction tx = program.openTransaction("Rename breakpoint")) {
			bookmark.set(bookmark.getCategory(), computeComment());
		}
		catch (ConcurrentModificationException e) {
			/**
			 * Can happen during breakpoint deletion. Doesn't seem like there's a good way to check.
			 * In any case, we need to keep processing events, so log and continue.
			 */
			Msg.error(this, "Could not update breakpoint properties: " + e);
		}
	}

	/**
	 * Get the user-defined name of the breakpoint
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the name of the breakpoint
	 * 
	 * @param name the name
	 */
	public void setName(String name) {
		Bookmark bookmark = getBookmark();
		if (bookmark == null) {
			throw new IllegalStateException("Must save breakpoint to program before naming it");
		}
		this.name = name;
		writeProperties(bookmark);
	}

	/**
	 * Get the sleigh injection for this breakpoint
	 * 
	 * @return the sleigh injection
	 */
	public String getEmuSleigh() {
		return sleigh;
	}

	/***
	 * Set the sleigh injection for this breakpoint
	 * 
	 * @param sleigh the sleigh injection
	 */
	public void setEmuSleigh(String sleigh) {
		this.sleigh = sleigh;
		Bookmark bookmark = getBookmark();
		if (bookmark == null) {
			return;
		}
		writeProperties(bookmark);
	}

	/**
	 * Compute the mode of this breakpoint
	 * 
	 * <p>
	 * In order to ensure at least the saved state (enablement) can be rendered in the marker margin
	 * in the absence of the breakpoint marker plugin, we use one type of bookmark for disabled
	 * breakpoints, and another for enabled breakpoints. As the state is changing, it's possible for
	 * a brief moment that both bookmarks are present. We thus have a variable for each bookmark and
	 * prefer the "enabled" state. We can determine are state by examining which variable is
	 * non-null. If both are null, the breakpoint is not actually saved to the program, yet. We
	 * cannot return {@link ProgramMode#NONE}, because that would imply there is no static location.
	 * 
	 * @return the state
	 */
	public ProgramMode computeMode() {
		if (eBookmark != null) {
			return ProgramMode.ENABLED;
		}
		if (dBookmark != null) {
			return ProgramMode.DISABLED;
		}
		return ProgramMode.MISSING;
	}

	/**
	 * Check if either bookmark is present
	 * 
	 * @return true if both are absent, false if either or both is present
	 */
	public boolean isEmpty() {
		return eBookmark == null && dBookmark == null;
	}

	/**
	 * Remove the bookmark
	 * 
	 * <p>
	 * Note this does not necessarily destroy the breakpoint, since it may still exist in one or
	 * more traces.
	 */
	public void deleteFromProgram() {
		// volatile reads
		Bookmark eBookmark = this.eBookmark;
		Bookmark dBookmark = this.dBookmark;
		try (Transaction tx = program.openTransaction("Clear breakpoint")) {
			BookmarkManager bookmarkManager = program.getBookmarkManager();
			if (eBookmark != null) {
				bookmarkManager.removeBookmark(eBookmark);
			}
			if (dBookmark != null) {
				bookmarkManager.removeBookmark(dBookmark);
			}
			// (e,d)Bookmark Gets nulled on program change callback
			// If null here, logical breakpoint manager will get confused
		}
	}

	/**
	 * Check if the given bookmark can fill the static side of this breakpoint
	 * 
	 * @param candProgram the program containing the bookmark
	 * @param candBookmark the bookmark
	 * @return true if the bookmark can represent this breakpoint, false otherwise
	 */
	public boolean canMerge(Program candProgram, Bookmark candBookmark) {
		if (program != candProgram) {
			return false;
		}
		if (!address.equals(candBookmark.getAddress())) {
			return false;
		}
		if (length != lengthFromBookmark(candBookmark)) {
			return false;
		}
		if (!Objects.equals(kinds, kindsFromBookmark(candBookmark))) {
			return false;
		}
		return true;
	}

	/**
	 * Get the program where this breakpoint is located
	 * 
	 * @return the program
	 */
	public Program getProgram() {
		return program;
	}

	/**
	 * Fill the static side of this breakpoint with the given bookmark
	 * 
	 * <p>
	 * The caller should first use {@link #canMerge(Program, Bookmark)} to ensure the bookmark can
	 * actually represent this breakpoint.
	 * 
	 * @param bookmark the bookmark
	 * @return true if this changed the breakpoint state
	 */
	public boolean add(Bookmark bookmark) {
		if (LogicalBreakpoint.ENABLED_BOOKMARK_TYPE.equals(bookmark.getTypeString())) {
			if (eBookmark == bookmark) {
				return false;
			}
			eBookmark = bookmark;
			syncProperties(bookmark);
			return true;
		}
		if (LogicalBreakpoint.DISABLED_BOOKMARK_TYPE.equals(bookmark.getTypeString())) {
			if (dBookmark == bookmark) {
				return false;
			}
			dBookmark = bookmark;
			syncProperties(bookmark);
			return true;
		}
		return false;
	}

	/**
	 * Remove a bookmark from the static side of this breakpoint
	 * 
	 * @param bookmark the bookmark
	 * @return true if this changed the breakpoint state
	 */
	public boolean remove(Bookmark bookmark) {
		if (eBookmark == bookmark) {
			eBookmark = null;
			return true;
		}
		if (dBookmark == bookmark) {
			dBookmark = null;
			return true;
		}
		return false;
	}

	/**
	 * Get the bookmark representing this breakpoint, if present
	 * 
	 * @return the bookmark or null
	 */
	public Bookmark getBookmark() {
		Bookmark eBookmark = this.eBookmark;
		if (eBookmark != null && !eBookmark.isDeleted()) {
			return eBookmark;
		}
		Bookmark dBookmark = this.dBookmark;
		if (dBookmark != null && !dBookmark.isDeleted()) {
			return dBookmark;
		}
		return null;
	}

	public List<Bookmark> getBookmarksValidOrNot() {
		Bookmark eBookmark = this.eBookmark;
		Bookmark dBookmark = this.dBookmark;
		List<Bookmark> result = new ArrayList<>();
		if (eBookmark != null) {
			result.add(eBookmark);
		}
		if (dBookmark != null) {
			result.add(dBookmark);
		}
		return result;
	}

	protected String getComment() {
		Bookmark bookmark = getBookmark();
		return bookmark == null ? computeComment() : bookmark.getComment();
	}

	/**
	 * Check if the bookmark represents an enabled breakpoint
	 * 
	 * @return true if enabled, false if anything else
	 */
	public boolean isEnabled() {
		return computeMode() == ProgramMode.ENABLED;
	}

	/**
	 * Check if the bookmark represents a disabled breakpoint
	 * 
	 * @return true if disabled, false if anything else
	 */
	public boolean isDisabled() {
		return computeMode() == ProgramMode.DISABLED;
	}

	/**
	 * Compute the category for a new bookmark representing this breakpoint
	 * 
	 * @return the category
	 */
	public String computeCategory() {
		return TraceBreakpointKindSet.encode(kinds) + ";" + Long.toUnsignedString(length);
	}

	/**
	 * In case a program database with pre-Ghidra-12.2 breakpoint bookmarks comes along (this will
	 * happen for a while), we want to ensure the old encodings are deleted when the breakpoint is
	 * toggled. While we'd normally strive for perfect backward compatibility, it's not as important
	 * for breakpoints here. If this function is to be removed later (it probably should be), we can
	 * either: 1) ensure there's some upgrade process, on import or via a script; or 2) just
	 * instruct users on a case-by-case basis to delete the old breakpoints.
	 * 
	 * @return the bookmark category for encoding the breakpoint kinds in versions prior to 12.2.
	 */
	protected String computeCategory_Pre12Dot2() {
		return kinds.stream().map(k -> k.name()).collect(Collectors.joining(",")) + ";" +
			Long.toUnsignedString(length);
	}

	/**
	 * Change the state of this breakpoint by manipulating bookmarks
	 * 
	 * <p>
	 * If the breakpoint is already in the desired state, no change is made. Otherwise, this will
	 * delete the existing bookmark, if present, and create a new bookmark whose type indicates the
	 * desired state. Thus, some event processing may need to take place before this breakpoint's
	 * state is actually updated accordingly.
	 * 
	 * @param enabled the desired state, true for {@link ProgramMode#ENABLED}, false for
	 *            {@link ProgramMode#DISABLED}.
	 * @param comment the comment to give the breakpoint, almost always from {@link #getComment()}.
	 */
	public void toggleWithComment(boolean enabled, String comment) {
		String addType =
			enabled ? LogicalBreakpoint.ENABLED_BOOKMARK_TYPE
					: LogicalBreakpoint.DISABLED_BOOKMARK_TYPE;
		String delType =
			enabled ? LogicalBreakpoint.DISABLED_BOOKMARK_TYPE
					: LogicalBreakpoint.ENABLED_BOOKMARK_TYPE;
		try (Transaction tx = program.openTransaction("Toggle breakpoint")) {
			BookmarkManager manager = program.getBookmarkManager();
			String catStr = computeCategory();
			String catStr_Pre12Dot2 = computeCategory_Pre12Dot2();
			manager.setBookmark(address, addType, catStr, comment);
			manager.removeBookmarks(new AddressSet(address), delType, catStr,
				TaskMonitor.DUMMY);
			manager.removeBookmarks(new AddressSet(address), delType, catStr_Pre12Dot2,
				TaskMonitor.DUMMY);
		}
		catch (CancelledException e) {
			throw new AssertionError(e);
		}
	}

	/**
	 * Enable this breakpoint
	 * 
	 * @see #toggleWithComment(boolean, String)
	 */
	public void enable() {
		if (isEnabled()) {
			return;
		}
		toggleWithComment(true, getComment());
	}

	/**
	 * Disable this breakpoint
	 * 
	 * @see #toggleWithComment(boolean, String)
	 */
	public void disable() {
		if (isDisabled()) {
			return;
		}
		toggleWithComment(false, getComment());
	}
}
