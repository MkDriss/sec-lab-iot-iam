/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.debug.api.modules;

import java.util.Objects;

import docking.DefaultActionContext;
import ghidra.trace.model.modules.TraceModule;

public class DebuggerMissingModuleActionContext extends DefaultActionContext {
	private final TraceModule module;
	private final long snap;
	private final int hashCode;

	public DebuggerMissingModuleActionContext(TraceModule module, long snap) {
		this.module = Objects.requireNonNull(module);
		this.hashCode = Objects.hash(getClass(), module, snap);
		this.snap = snap;
	}

	public TraceModule getModule() {
		return module;
	}

	public long getSnap() {
		return snap;
	}

	@Override
	public int hashCode() {
		return hashCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof DebuggerMissingModuleActionContext that)) {
			return false;
		}
		if (!this.module.equals(that.module)) {
			return false;
		}
		if (this.snap != that.snap) {
			return false;
		}
		return true;
	}
}
