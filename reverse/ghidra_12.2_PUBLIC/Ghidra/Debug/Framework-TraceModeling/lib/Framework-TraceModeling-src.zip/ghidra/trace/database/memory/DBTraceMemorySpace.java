/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.trace.database.memory;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.function.Predicate;

import db.DBHandle;
import ghidra.lifecycle.Internal;
import ghidra.program.model.address.*;
import ghidra.program.model.mem.MemBuffer;
import ghidra.trace.database.DBTrace;
import ghidra.trace.database.DBTraceTimeViewport;
import ghidra.trace.database.DBTraceUtils.OffsetSnap;
import ghidra.trace.database.listing.DBTraceCodeSpace;
import ghidra.trace.database.map.DBTraceAddressSnapRangePropertyMapAddressSetView;
import ghidra.trace.database.map.DBTraceAddressSnapRangePropertyMapSpace;
import ghidra.trace.database.map.DBTraceAddressSnapRangePropertyMapTree.Painter;
import ghidra.trace.database.map.DBTraceAddressSnapRangePropertyMapTree.TraceAddressSnapRangeQuery;
import ghidra.trace.database.space.AbstractDBTraceSpaceBasedManager.DBTraceSpaceEntry;
import ghidra.trace.database.space.DBTraceSpaceBased;
import ghidra.trace.model.*;
import ghidra.trace.model.memory.TraceMemorySpace;
import ghidra.trace.model.memory.TraceMemoryState;
import ghidra.trace.util.*;
import ghidra.util.*;
import ghidra.util.AddressIteratorAdapter;
import ghidra.util.database.*;
import ghidra.util.database.spatial.DBTreeNodeRecord;
import ghidra.util.database.spatial.DBTreeRecord;
import ghidra.util.database.spatial.rect.Rectangle2DDirection;
import ghidra.util.datastruct.FixedSizeHashMap;
import ghidra.util.exception.VersionException;
import ghidra.util.task.TaskMonitor;

/**
 * Implements {@link TraceMemorySpace} using a database-backed copy-on-write store.
 */
public class DBTraceMemorySpace
		implements TraceMemorySpace, InternalTraceMemoryOperations, DBTraceSpaceBased {
	public static final int BLOCK_SHIFT = 12;
	public static final int BLOCK_SIZE = 1 << BLOCK_SHIFT;
	public static final int BLOCK_MASK = -1 << BLOCK_SHIFT;
	public static final int DEPENDENT_COMPRESSED_SIZE_TOLERANCE = BLOCK_SIZE >>> 2;
	public static final int BLOCK_CACHE_SIZE = 10;

	public static final int BLOCKS_PER_BUFFER = 256; // Must be a power of 2 and >= 8;

	public static final int STATE_BLOCK_SHIFT = 8;
	public static final int STATE_BLOCK_SIZE = 1 << STATE_BLOCK_SHIFT;
	public static final int STATE_BLOCK_MASK = -1 << STATE_BLOCK_SHIFT;
	public static final int STATE_CACHE_SIZE = 500;

	public static final int STATE_MR_CACHE_SIZE = 100;

	record AddressSetStateCacheKey(Lifespan span, long offset, StatePredicate predicate) {}

	record MostRecentStateCacheKey(long snap, Address address) {}

	protected final DBTraceMemoryManager manager;
	protected final DBHandle dbh;
	protected final AddressSpace space;
	protected final ReadWriteLock lock;
	protected final DBTrace trace;

	protected final DBTraceAddressSnapRangePropertyMapSpace<TraceMemoryState,
		DBTraceMemoryStateEntry> stateMapSpace;

	protected final DBCachedObjectStore<DBTraceMemoryBufferEntry> bufferStore;
	protected final DBCachedObjectStore<DBTraceMemoryBlockEntry> blockStore;
	protected final DBCachedObjectIndex<OffsetSnap, DBTraceMemoryBlockEntry> blocksByOffset;
	protected final Map<OffsetSnap, DBTraceMemoryBlockEntry> blockCacheMostRecent =
		Collections.synchronizedMap(new FixedSizeHashMap<>(BLOCK_CACHE_SIZE));
	protected final Map<AddressSetStateCacheKey, AddressSetView> addressSetStateCache =
		Collections.synchronizedMap(new FixedSizeHashMap<>(STATE_CACHE_SIZE));
	protected final Map<MostRecentStateCacheKey,
		Entry<TraceAddressSnapRange, TraceMemoryState>> mostRecentStateEntryCache =
			Collections.synchronizedMap(new FixedSizeHashMap<>(STATE_MR_CACHE_SIZE));

	protected final DBTraceTimeViewport viewport;

	public DBTraceMemorySpace(DBTraceMemoryManager manager, DBHandle dbh, AddressSpace space,
			DBTraceSpaceEntry ent) throws IOException, VersionException {
		this.manager = manager;
		this.dbh = dbh;
		this.space = space;
		this.lock = manager.getLock();
		this.trace = manager.getTrace();

		DBCachedObjectStoreFactory factory = trace.getStoreFactory();

		// TODO: Remove the Exp thing from this and related
		this.stateMapSpace = new DBTraceAddressSnapRangePropertyMapSpace<>(
			DBTraceMemoryStateEntry.tableName(space), trace, factory, lock, space,
			DBTraceMemoryStateEntry.class, DBTraceMemoryStateEntry::new);

		this.bufferStore = factory.getOrCreateCachedStore(
			DBTraceMemoryBufferEntry.tableName(space), DBTraceMemoryBufferEntry.class,
			(s, r) -> new DBTraceMemoryBufferEntry(dbh, s, r), true);

		this.blockStore = factory.getOrCreateCachedStore(
			DBTraceMemoryBlockEntry.tableName(space), DBTraceMemoryBlockEntry.class,
			(s, r) -> new DBTraceMemoryBlockEntry(this, s, r), true);
		this.blocksByOffset =
			blockStore.getIndex(OffsetSnap.class, DBTraceMemoryBlockEntry.LOCATION_COLUMN);

		this.viewport = trace.createTimeViewport();
	}

	@Override
	public AddressSpace getSpace() {
		return space;
	}

	@Override
	public ReadWriteLock getLock() {
		return lock;
	}

	@Override
	public Trace getTrace() {
		return trace;
	}

	@Override
	public DBTraceCodeSpace getCodeSpace(boolean createIfAbsent) {
		return trace.getCodeManager().getCodeSpace(space, createIfAbsent);
	}

	@Override
	public AddressSpace getAddressSpace() {
		return space;
	}

	protected void doPutState(AddressRange range, Lifespan span, TraceMemoryState state) {
		if (!range.getMinAddress().equals(range.getAddressSpace().getMinAddress())) {
			Entry<TraceAddressSnapRange, TraceMemoryState> candidateLeft = stateMapSpace
					.reduce(TraceAddressSnapRangeQuery.at(range.getMinAddress().previous(),
						span.lmin()))
					.firstEntry();
			if (candidateLeft != null && candidateLeft.getValue() == state &&
				candidateLeft.getKey().getLifespan().equals(span)) {
				range = new AddressRangeImpl(candidateLeft.getKey().getRange().getMinAddress(),
					range.getMaxAddress());
				stateMapSpace.remove(candidateLeft);
			}
		}
		if (!range.getMaxAddress().equals(range.getAddressSpace().getMaxAddress())) {
			Entry<TraceAddressSnapRange, TraceMemoryState> candidateRight = stateMapSpace
					.reduce(TraceAddressSnapRangeQuery.at(range.getMaxAddress().next(),
						span.lmin()))
					.firstEntry();
			if (candidateRight != null && candidateRight.getValue() == state &&
				candidateRight.getKey().getLifespan().equals(span)) {
				range = new AddressRangeImpl(range.getMinAddress(),
					candidateRight.getKey().getRange().getMaxAddress());
				stateMapSpace.remove(candidateRight);
			}
		}
		stateMapSpace.put(range, span, state);
	}

	protected void doTruncateAndPut(long snap, AddressSet remains, TraceMemoryState state) {
		if (remains.isEmpty()) {
			return;
		}
		Lifespan nowOn = Lifespan.nowOnMaybeScratch(snap);
		// If there can't be anything ahead, just add it and be done
		if (nowOn.lmin() == nowOn.lmax()) {
			for (AddressRange rng : remains) {
				doPutState(rng, nowOn, state);
			}
			return;
		}
		// Scan ahead to see how the new entry should be split, if truncation is needed
		Lifespan future = Lifespan.nowOnMaybeScratch(snap + 1);
		Iterator<Entry<TraceAddressSnapRange, TraceMemoryState>> it = stateMapSpace
				.reduce(TraceAddressSnapRangeQuery.intersectingEnclosed(
					new AddressRangeImpl(remains.getMinAddress(), remains.getMaxAddress()), future)
						.starting(Rectangle2DDirection.BOTTOMMOST))
				.orderedEntries()
				.iterator();
		// Avoid concurrent modification, lest new entries confuse our splitting
		List<TraceAddressSnapRange> toAdd = new ArrayList<>();
		while (!remains.isEmpty() && it.hasNext()) {
			Entry<TraceAddressSnapRange, TraceMemoryState> next = it.next();
			if (next.getValue() != TraceMemoryState.KNOWN) {
				continue;
			}
			TraceAddressSnapRange key = next.getKey();
			AddressSet intersection = remains.intersectRange(key.getRange());
			if (!intersection.isEmpty()) {
				Lifespan portion = Lifespan.span(snap, key.getLifespan().lmin() - 1);
				for (AddressRange rng : intersection) {
					toAdd.add(new ImmutableTraceAddressSnapRange(rng, portion));
				}
			}
			remains.delete(key.getRange());
		}
		for (AddressRange rng : remains) { // may be empty, anyway
			toAdd.add(new ImmutableTraceAddressSnapRange(rng, nowOn));
		}

		for (TraceAddressSnapRange box : toAdd) {
			doPutState(box.getRange(), box.getLifespan(), state);
		}
	}

	protected void doSetState(long snap, Address start, Address end, TraceMemoryState state) {
		Objects.requireNonNull(state);
		AddressRangeImpl range = new AddressRangeImpl(start, end);
		AddressSet remains = new AddressSet(range);
		AddressSet toExpand = state.truncates() ? null : new AddressSet();
		List<Entry<TraceAddressSnapRange, TraceMemoryState>> truncated = new ArrayList<>();

		// Where the desired state is already present, do nothing
		var exist = List.copyOf(stateMapSpace
				.reduce(TraceAddressSnapRangeQuery.intersecting(range, Lifespan.at(snap)))
				.entries());
		for (Entry<TraceAddressSnapRange, TraceMemoryState> ex : exist) {
			TraceAddressSnapRange key = ex.getKey();
			if (key.getLifespan().lmin() == snap) {
				if (ex.getValue() == state) {
					remains.delete(key.getRange());
				}
				else {
					AddressSet diff = new AddressSet(key.getRange());
					diff.delete(range);
					for (AddressRange d : diff) {
						truncated.add(Map.entry(new ImmutableTraceAddressSnapRange(
							d, key.getLifespan()), ex.getValue()));
					}

					stateMapSpace.remove(ex);
					if (toExpand != null /* New value does not truncate */ &&
						ex.getValue().truncates() /* Old value truncates */) {
						toExpand.add(key.getRange());
					}
				}
			}
		}

		// Implies nothing needs to change, and toExpand ought be be empty too
		if (remains.isEmpty() && (toExpand == null || toExpand.isEmpty())) {
			return;
		}

		/**
		 * Truncate or delete the existing entries to make room for the new entries. Every entry is
		 * truncated at KNOWN. No entry is truncated by ERROR, so queries must sort that out.
		 */
		if (state.truncates()) {
			if (!remains.isEmpty()) {
				// Remove existing entries to make room. We'll add them back (truncated) later
				for (Entry<TraceAddressSnapRange, TraceMemoryState> entry : exist) {
					if (remains.intersects(entry.getKey().getRange())) {
						stateMapSpace.remove(entry);
						truncated.add(Map.entry(entry.getKey(), entry.getValue()));
					}
				}
			}
		}
		else {
			/**
			 * It's possible truncating values were removed, permitting entries from the previous
			 * snap to expand forward. Those entries may need to be split, depending on what
			 * truncating entries are in the future.
			 */
			if (snap != Long.MIN_VALUE && snap != 0) { // Is there a previous snap?
				Lifespan prev = Lifespan.at(snap - 1);
				for (AddressRange exp : toExpand) {
					for (Entry<TraceAddressSnapRange, TraceMemoryState> entry : stateMapSpace
							.reduce(TraceAddressSnapRangeQuery.intersecting(exp, prev))
							.entries()) {
						stateMapSpace.remove(entry);
						doTruncateAndPut(entry.getKey().getLifespan().lmin(),
							new AddressSet(entry.getKey().getRange()), entry.getValue());
					}
				}
			}
		}

		if (!state.impliedByNull() && remains != null) {
			doTruncateAndPut(snap, remains, state);
		}

		for (Entry<TraceAddressSnapRange, TraceMemoryState> entry : truncated) {
			TraceAddressSnapRange key = entry.getKey();
			doTruncateAndPut(key.getLifespan().lmin(), new AddressSet(key.getRange()),
				entry.getValue());
		}

		addressSetStateCache.clear();
		mostRecentStateEntryCache.clear();
		// TODO: Maybe the end snap should extend as far into the future as was actually written?
		trace.setChanged(new TraceChangeRecord<>(TraceEvents.BYTES_STATE_CHANGED, space,
			new ImmutableTraceAddressSnapRange(start, end, snap, snap), state));
	}

	protected void checkState(TraceMemoryState state) {
		/**
		 * TODO: I don't remember why I prohibited this originally. It seems some technicality in
		 * calling something "last known?" We might revisit and specify that definition, in the face
		 * of memory being invalidated while the target is suspended. It seems appropriate to leave
		 * the stale bytes in the trace, but change the state to UNKNOWN. Do those stale bytes still
		 * count as last known? Aside from getBytes, I don't see anything that requires a precise
		 * distinction. We might be careful how this interacts with removeBytes, though.... Well,
		 * AFAICT, it doesn't depend on state markings. For now, I'm going to allow it. We'll see
		 * what happens. Changing this had no effect on the unit tests :/ .
		 */
		/*if (state == null || state == TraceMemoryState.UNKNOWN) {
			throw new IllegalArgumentException("Cannot erase memory state without removing bytes");
		}*/
	}

	public void checkStateMapIntegrity() {
		stateMapSpace.checkIntegrity();
	}

	@Override
	// TODO: Ensure a code unit is not having rug taken out from under it?
	public void setState(long snap, Address start, Address end, TraceMemoryState state) {
		checkState(state);
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			doSetState(snap, start, end, state);
		}
	}

	@Override
	public void setState(long snap, AddressRange range, TraceMemoryState state) {
		checkState(state);
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			doSetState(snap, range.getMinAddress(), range.getMaxAddress(), state);
		}
	}

	@Override
	public void setState(long snap, Address address, TraceMemoryState state) {
		checkState(state);
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			doSetState(snap, address, address, state);
		}
	}

	@Override
	public void setState(long snap, AddressSetView set, TraceMemoryState state) {
		checkState(state);
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			for (AddressRange range : set) {
				doSetState(snap, range.getMinAddress(), range.getMaxAddress(), state);
			}
		}
	}

	@Override
	public TraceMemoryState getState(long snap, Address address) {
		return TraceMemoryState.orImplied(
			stateMapSpace.reduce(TraceAddressSnapRangeQuery.minAt(address, snap)).firstValue());
	}

	@Override
	public Entry<Long, TraceMemoryState> getViewState(long snap, Address address) {
		for (Lifespan span : viewport.getOrderedSpans(snap)) {
			TraceMemoryState state = getState(span.lmax(), address);
			switch (state) {
				case KNOWN, ERROR -> {
					return Map.entry(span.lmax(), state);
				}
				default -> { // fall through
				}
			}
			// Only the snap with the schedule specified gets the source snap's states
			if (span.lmax() - span.lmin() > 0) {
				return Map.entry(snap, TraceMemoryState.UNKNOWN);
			}
		}
		return Map.entry(snap, TraceMemoryState.UNKNOWN);
	}

	@Override
	public Entry<TraceAddressSnapRange, TraceMemoryState> getMostRecentStateEntry(long snap,
			Address address) {
		return stateMapSpace.reduce(TraceAddressSnapRangeQuery.mostRecent(address, snap))
				// not .firstEntry(), because TOPMOST sorts by Y2
				.entries()
				.stream()
				.sorted(Comparator.comparing(e -> -e.getKey().getY1()))
				.findFirst()
				.orElse(null);
	}

	@Override
	public Entry<TraceAddressSnapRange, TraceMemoryState> getViewMostRecentStateEntry(long snap,
			Address address) {
		// LATER: Cache here or on the delegate?
		return mostRecentStateEntryCache.computeIfAbsent(new MostRecentStateCacheKey(snap, address),
			_ -> getViewMostRecentStateEntry(snap, new AddressRangeImpl(address, address),
				StatePredicate.IS_KNOWN_OR_ERROR));
	}

	@Override
	public Entry<TraceAddressSnapRange, TraceMemoryState> getViewMostRecentStateEntry(long snap,
			AddressRange range, Predicate<TraceMemoryState> predicate) {
		assertInSpace(range);
		for (Lifespan span : viewport.getOrderedSpans(snap)) {
			var entry = stateMapSpace.reduce(TraceAddressSnapRangeQuery.mostRecent(range, span))
					.entries() // not ordered, since we're doing our own sort
					.stream()
					.filter(e -> predicate.test(e.getValue()))
					// TOPMOST sorts by Y2
					.sorted(Comparator.comparing(e -> -e.getKey().getY1()))
					.findFirst();
			if (entry.isPresent()) {
				return entry.get();
			}
		}
		return null;
	}

	@Override
	public AddressSetView getAddressesWithState(long snap, Predicate<TraceMemoryState> predicate) {
		return new DBTraceAddressSnapRangePropertyMapAddressSetView<>(space, lock,
			stateMapSpace.reduce(TraceAddressSnapRangeQuery.minAtSnap(snap, space)),
			predicate);
	}

	@Override
	public AddressSetView getAddressesWithState(Lifespan lifespan,
			Predicate<TraceMemoryState> predicate) {
		return new DBTraceAddressSnapRangePropertyMapAddressSetView<>(space, lock,
			stateMapSpace.reduce(TraceAddressSnapRangeQuery.minWithin(lifespan, space)),
			predicate);
	}

	@Override
	public AddressSetView getAddressesWithState(Lifespan span, AddressSetView set,
			Predicate<TraceMemoryState> predicate) {
		try (LockHold _ = LockHold.lock(lock.readLock())) {
			if (!(predicate instanceof StatePredicate stock)) {
				return doGetAddressesWithState(span, set, predicate);
			}
			AddressSet remains = new AddressSet(set);
			AddressSet result = new AddressSet();
			while (!remains.isEmpty()) {
				Address min = remains.getMinAddress();
				long blockMinOffset = min.getOffset() & STATE_BLOCK_MASK;
				Address blockMin = min.getNewAddress(blockMinOffset);
				Address blockMax = blockMin.add(STATE_BLOCK_SIZE - 1);
				remains.delete(min, blockMax);

				result.add(addressSetStateCache.computeIfAbsent(
					new AddressSetStateCacheKey(span, blockMinOffset, stock),
					_ -> doGetAddressesWithState(span, new AddressSet(blockMin, blockMax), stock)));
			}
			return result.intersect(set);
		}
	}

	protected AddressSetView doGetAddressesWithState(Lifespan span, AddressSetView set,
			Predicate<TraceMemoryState> predicate) {
		AddressSet remains = new AddressSet(set);
		AddressSet result = new AddressSet();
		while (!remains.isEmpty()) {
			AddressRange range = remains.getFirstRange();
			AddressSet subRem = new AddressSet(range);
			remains.delete(range);
			for (Entry<TraceAddressSnapRange, TraceMemoryState> entry : doGetStates(span, range)) {
				AddressRange foundRange = entry.getKey().getRange();
				if (predicate.test(entry.getValue())) {
					result.add(foundRange);
					remains.delete(foundRange); // Could intersect a later range
					subRem.delete(foundRange);
					if (subRem.isEmpty()) {
						break;
					}
				}
			}
			if (remains.isEmpty()) {
				return result;
			}
		}
		return result;
	}

	protected Collection<Entry<TraceAddressSnapRange, TraceMemoryState>> doGetStates(Lifespan span,
			AddressRange range) {
		// LATER: A better way to handle memory-mapped registers?
		AddressSpace thisSpace = getAddressSpace();
		if (thisSpace.isRegisterSpace() && !range.getAddressSpace().isRegisterSpace()) {
			return trace.getMemoryManager().doGetStates(span, range);
		}
		if (thisSpace != range.getAddressSpace()) {
			range = new AddressRangeImpl(
				thisSpace.getOverlayAddress(range.getMinAddress()),
				thisSpace.getOverlayAddress(range.getMaxAddress()));
		}
		var subMap =
			stateMapSpace.reduce(TraceAddressSnapRangeQuery.intersectingMinWithin(range, span));
		return subMap.entries();
		/*@SuppressWarnings({ "unchecked", "rawtypes" })
		List<Entry<TraceAddressSnapRange, TraceMemoryState>> asList =
			(List) Arrays.asList(subMap.entries().toArray());
		return asList;*/
	}

	@Override
	public Collection<Entry<TraceAddressSnapRange, TraceMemoryState>> getStates(long snap,
			AddressRange range) {
		assertInSpace(range);
		return doGetStates(Lifespan.at(snap), range);
	}

	@Override
	public Iterable<Entry<TraceAddressSnapRange, TraceMemoryState>> getMostRecentStates(
			TraceAddressSnapRange within) {
		return stateMapSpace
				.reduce(
					TraceAddressSnapRangeQuery.mostRecent(within.getRange(), within.getLifespan()))
				.orderedEntries();
	}

	protected DBTraceMemoryBlockEntry findMostRecentBlockEntry(OffsetSnap loc, boolean inclusive) {
		DBTraceMemoryBlockEntry ent = null;
		Iterator<DBTraceMemoryBlockEntry> it;
		if (!inclusive) {
			loc = new OffsetSnap(loc.offset, loc.snap - 1);
		}
		ent = blockCacheMostRecent.get(loc);
		if (ent != null) {
			return ent;
		}
		it = blocksByOffset.head(loc, true).descending().values().iterator();
		if (!it.hasNext()) {
			return null;
		}
		ent = it.next();
		if (ent.getOffset() != loc.offset || ent.isScratch() != loc.isScratch()) {
			return null;
		}
		blockCacheMostRecent.put(loc, ent);
		return ent;
	}

	/**
	 * Locate the soonest block entry for the given offset-snap pair
	 * 
	 * <p>
	 * To qualify, the entry must have a snap greater than (or optionally equal to) that given and
	 * an offset exactly equal to that given. That is, it is the earliest in time, but most follow
	 * the given snap. Additionally, if the given snap is in scratch space, the found entry must
	 * also be in scratch space.
	 * 
	 * @param loc the offset-snap pair
	 * @param inclusive true to allow equal snap
	 * @return the found entry, or null
	 */
	protected DBTraceMemoryBlockEntry findSoonestBlockEntry(OffsetSnap loc, boolean inclusive) {
		Iterator<DBTraceMemoryBlockEntry> it;
		if (inclusive) {
			it = blocksByOffset.tail(loc, true).values().iterator();
		}
		else {
			it = blocksByOffset.tail(new OffsetSnap(loc.offset, loc.snap + 1),
				true).values().iterator();
		}
		if (!it.hasNext()) {
			return null;
		}
		DBTraceMemoryBlockEntry next = it.next();
		if (next.getOffset() != loc.offset || next.isScratch() != loc.isScratch()) {
			return null;
		}
		return next;
	}

	protected void doPutBytes(OffsetSnap loc, ByteBuffer buf, int dstOffset, int maxLen)
			throws IOException {
		// Cases:
		// 1) An entry does not exist
		// 2) An entry does exist, but it's not "present"
		// 2a) The update does not cause a change
		// 2b) The update does cause a change
		// 3) An entry exists, and it's present
		DBTraceMemoryBlockEntry ent = findMostRecentBlockEntry(loc, true);
		if (ent != null) { // Deal with (1) later
			if (ent.getSnap() == loc.snap) { // (3) Just update it.
				// No need to compare, because a NOP set won't hurt.
				ent.setBytes(buf, dstOffset, maxLen);
				return;
			}
			// (2)...
			if (ent.cmpBytes(buf, dstOffset, maxLen) == 0) {
				// (2a)
				buf.position(buf.position() + maxLen);
				return;
			}
			ent = ent.copy(loc);
			ent.setBytes(buf, dstOffset, maxLen);
			return;
		}
		// (1) or (2b)
		ent = blockStore.create();
		ent.setLoc(loc);
		blockCacheMostRecent.clear();
		blockCacheMostRecent.put(loc, ent);
		if (ent.cmpBytes(buf, dstOffset, maxLen) == 0) {
			// Keep the entry, but don't allocate storage in a buffer
			buf.position(buf.position() + maxLen);
			return;
		}
		ent.setBytes(buf, dstOffset, maxLen);
	}

	protected static class OutSnap {
		long snap;

		public OutSnap(long snap) {
			this.snap = snap;
		}
	}

	protected void doPutFutureBytes(OffsetSnap loc, ByteBuffer buf, int dstOffset, int maxLen,
			OutSnap lastSnap, Set<TraceAddressSnapRange> changed) throws IOException {
		if (loc.snap == Lifespan.DOMAIN.lmax()) {
			return;
		}
		// NOTE: Do not leave the buffer advanced from here
		int pos = buf.position();
		// exclusive?
		Iterator<DBTraceMemoryBlockEntry> it =
			blocksByOffset.tail(new OffsetSnap(loc.offset, loc.snap + 1), true).values().iterator();
		AddressSet remaining = new AddressSet(space.getAddress(loc.offset + dstOffset),
			space.getAddress(loc.offset + dstOffset + maxLen - 1));
		while (it.hasNext()) {
			DBTraceMemoryBlockEntry next = it.next();
			if (next.getOffset() != loc.offset || next.isScratch() != loc.isScratch()) {
				break;
			}
			AddressSetView withState =
				getAddressesWithState(next.getSnap(), remaining, StatePredicate.IS_KNOWN_OR_ERROR);
			remaining = remaining.subtract(withState);
			long endSnap = next.getSnap() - 1;
			for (AddressRange rng : withState) {
				changed.add(
					new ImmutableTraceAddressSnapRange(rng, Lifespan.span(loc.snap, endSnap)));
			}
			if (remaining.isEmpty()) {
				lastSnap.snap = endSnap;
				break;
			}
			for (AddressRange rng : remaining) {
				int subOffset = (int) (rng.getMinAddress().getOffset() - loc.offset);
				buf.position(pos + subOffset - dstOffset);
				next.setBytes(buf, subOffset, (int) rng.getLength());
			}
		}
		if (!remaining.isEmpty()) {
			lastSnap.snap = Lifespan.DOMAIN.lmax();
			for (AddressRange rng : remaining) {
				changed.add(
					new ImmutableTraceAddressSnapRange(rng, Lifespan.nowOnMaybeScratch(loc.snap)));
			}
		}
		buf.position(pos);
	}

	protected int doPutBytes(long snap, Address start, ByteBuffer buf, OutSnap lastSnap,
			Set<TraceAddressSnapRange> changed) throws IOException {
		int result = 0;
		try {
			int maxLen;
			for (Address cur = start; buf.hasRemaining(); cur = cur.addNoWrap(maxLen)) {
				long offset = cur.getOffset();
				long roundOffset = offset & BLOCK_MASK;
				int dstOffset = (int) (offset - roundOffset);
				maxLen = Math.min(BLOCK_SIZE - dstOffset, buf.remaining());
				OffsetSnap loc = new OffsetSnap(roundOffset, snap);
				doPutFutureBytes(loc, buf, dstOffset, maxLen, lastSnap, changed);
				doPutBytes(loc, buf, dstOffset, maxLen);
				result += maxLen;
			}
		}
		catch (AddressOverflowException e) {
			// exited loop
		}
		return result;
	}

	@Override
	public int putBytes(long snap, Address start, ByteBuffer buf) {
		assertInSpace(start);

		int pos = buf.position();
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			ByteBuffer oldBuf = ByteBuffer.allocate(buf.remaining());
			getBytes(snap, start, oldBuf);
			oldBuf.flip();

			OutSnap lastSnap = new OutSnap(snap);
			Set<TraceAddressSnapRange> changed = new HashSet<>();
			int result = doPutBytes(snap, start, buf, lastSnap, changed);
			if (result > 0) {
				Address end = start.add(result - 1);
				doSetState(snap, start, end, TraceMemoryState.KNOWN);

				ImmutableTraceAddressSnapRange tasr = new ImmutableTraceAddressSnapRange(start,
					start.add(result - 1), snap, lastSnap.snap);
				// Fire event
				if (trace.isSendingEvents()) {
					byte[] bytes = ByteArrayUtils.arrayOrGet(buf);
					byte[] oldBytes = ByteArrayUtils.arrayOrGet(oldBuf);
					trace.setChanged(new TraceChangeRecord<>(TraceEvents.BYTES_CHANGED, space, tasr,
						oldBytes, bytes));
				}

				// Fixup affected code units
				DBTraceCodeSpace codeSpace = trace.getCodeManager().get(space, false);
				if (codeSpace != null) {
					int savePos = buf.position();
					int saveLimit = buf.limit();
					try {
						buf.limit(pos + result);
						buf.position(pos);
						oldBuf.limit(oldBuf.position() + result); // No need to save & restore
						codeSpace.bytesChanged(changed, snap, start, oldBuf, buf);
					}
					finally {
						buf.limit(saveLimit);
						buf.position(savePos);
					}
				}
				// Clear program view caches
				trace.updateViewsBytesChanged(tasr.getRange());
			}
			return result;
		}
		catch (IOException e) {
			blockStore.dbError(e);
			return 0;
		}
	}

	protected void doGetBytes(OffsetSnap loc, ByteBuffer buf, int srcOffset, int maxLen)
			throws IOException {
		DBTraceMemoryBlockEntry ent = findMostRecentBlockEntry(loc, true);
		if (ent == null) {
			// TODO: Write zeroes instead?
			buf.position(buf.position() + maxLen);
		}
		else {
			ent.getBytes(buf, srcOffset, maxLen);
		}
	}

	@Override
	public int getBytes(long snap, Address start, ByteBuffer buf) {
		assertInSpace(start);
		int result = 0;
		try (LockHold _ = LockHold.lock(lock.readLock())) {
			int maxLen;
			for (Address cur = start; buf.hasRemaining(); cur = cur.addNoWrap(maxLen)) {
				long offset = cur.getOffset();
				long roundOffset = offset & BLOCK_MASK;
				int srcOffset = (int) (offset - roundOffset);
				maxLen = Math.min(BLOCK_SIZE - srcOffset, buf.remaining());
				OffsetSnap loc = new OffsetSnap(roundOffset, snap);
				doGetBytes(loc, buf, srcOffset, maxLen);
				result += maxLen;
			}
		}
		catch (AddressOverflowException e) {
			// exited loop
		}
		catch (IOException e) {
			blockStore.dbError(e);
		}
		return result;
	}

	protected int truncateLen(int len, Address start) {
		long maxLen = start.getAddressSpace().getMaxAddress().subtract(start) + 1;
		if (maxLen == 0) {
			// Only happens when min=0 and max=ffff_ffff_ffff_ffff
			return len;
		}
		return MathUtilities.unsignedMin(len, maxLen);
	}

	@Override
	public int getViewBytes(long snap, Address start, ByteBuffer buf) {
		assertInSpace(start);
		int len = truncateLen(buf.remaining(), start);
		if (len == 0) {
			return 0;
		}
		AddressRange toRead;
		try {
			toRead = new AddressRangeImpl(start, len);
		}
		catch (AddressOverflowException e) {
			throw new AssertionError(e);
		}
		Map<AddressRange, Long> sources = new TreeMap<>();
		AddressSet remains = new AddressSet(toRead);

		spans: for (Lifespan span : viewport.getOrderedSpans(snap)) {
			Iterator<AddressRange> arit =
				getAddressesWithState(span, remains, StatePredicate.IS_KNOWN).iterator(start, true);
			while (arit.hasNext()) {
				AddressRange rng = arit.next();
				if (rng.getMinAddress().compareTo(toRead.getMaxAddress()) > 0) {
					break;
				}
				for (AddressRange sub : remains.intersectRange(rng.getMinAddress(),
					rng.getMaxAddress())) {
					sources.put(sub, span.lmax());
				}
				remains.delete(rng);
				if (remains.isEmpty()) {
					break spans;
				}
			}
		}
		int lim = buf.limit();
		int pos = buf.position();
		for (Map.Entry<AddressRange, Long> ent : sources.entrySet()) {
			AddressRange rng = ent.getKey();
			int offset = (int) rng.getMinAddress().subtract(toRead.getMinAddress());
			int length = (int) rng.getLength();
			buf.limit(pos + offset + length);
			while (buf.position() < pos + offset) {
				buf.put((byte) 0); // fill gaps with 0
			}
			int read = getBytes(ent.getValue(), rng.getMinAddress(), buf);
			if (read < length) {
				break;
			}
		}
		// We "got it all", even if there were gaps in "KNOWN"
		buf.limit(lim);
		while (buf.position() < pos + len) {
			buf.put((byte) 0); // fill final gap with 0
		}
		return len;
	}

	protected Address doFindBytesInRange(long snap, AddressRange range, ByteBuffer data,
			ByteBuffer mask, boolean forward, TaskMonitor monitor) {
		int len = data.capacity();
		assert len != 0; // Caller should have checked
		if (range.getLength() > 0 /*treat length unsigned*/ && range.getLength() < len) {
			return null;
		}

		AddressRange rangeOfStarts =
			new AddressRangeImpl(range.getMinAddress(), range.getMaxAddress().subtract(len - 1));
		ByteBuffer read = ByteBuffer.allocate(len);
		for (Address addr : AddressIteratorAdapter.forRange(rangeOfStarts, forward)) {
			monitor.incrementProgress(1);
			if (monitor.isCancelled()) {
				return null;
			}
			read.clear();
			int l = getBytes(snap, addr, read);
			if (l != len) {
				continue;
			}
			if (!ByteBufferUtils.maskedEquals(mask, data, read)) {
				continue;
			}
			return addr;
		}
		return null;
	}

	@Override
	public Address findBytes(long snap, AddressRange range, ByteBuffer data, ByteBuffer mask,
			boolean forward, TaskMonitor monitor) {
		// ProgramDB uses the naive method with some skipping, so here we go....
		// TODO: This could be made faster by skipping over non-initialized blocks
		// TODO: DFA method would be complicated by masks....
		int len = data.capacity();
		if (mask != null && mask.capacity() != len) {
			throw new IllegalArgumentException("data and mask must have same capacity");
		}
		if (len == 0 ||
			range.getLength() > 0 /*treat length unsigned*/ && range.getLength() < len) {
			return null;
		}

		// LATER: Worry about the viewport, too?
		// This will reduce the search to ranges that have any once-known value at the snap.
		// NOTE: Potentially costly to pre-compute the set concretely
		AddressSet known = new AddressSet(
			stateMapSpace.getAddressSetView(Lifespan.at(snap), StatePredicate.IS_KNOWN))
					.intersect(new AddressSet(range));
		monitor.initialize(known.getNumAddresses());
		for (AddressRange knownRange : known.getAddressRanges(forward)) {
			Address found = doFindBytesInRange(snap, knownRange, data, mask, forward, monitor);
			if (found != null) {
				return found;
			}
		}
		return null;
	}

	protected boolean doCheckBytesChanged(OffsetSnap loc, int srcOffset, int maxLen,
			ByteBuffer eBuf, ByteBuffer pBuf) throws IOException {
		DBTraceMemoryBlockEntry ent = findMostRecentBlockEntry(loc, true);
		if (ent == null || ent.getSnap() < loc.snap) {
			return false;
		}
		DBTraceMemoryBlockEntry pre = findMostRecentBlockEntry(loc, false);
		int eLen = ent.getBytes(eBuf, srcOffset, maxLen);
		assert eLen == maxLen;
		eBuf.flip();
		if (pre == null) {
			return !DBTraceMemoryBlockEntry.isZeroes(eBuf, eLen);
		}
		int pLen = pre.getBytes(pBuf, srcOffset, maxLen);
		pBuf.flip();
		assert eLen == pLen;
		for (int i = 0; i < eLen; i++) {
			if (eBuf.get(i) != pBuf.get(i)) {
				return true;
			}
		}
		return false;
	}

	protected boolean doCheckBytesChanged(long snap, AddressRange range, ByteBuffer buf1,
			ByteBuffer buf2) throws IOException {
		try {
			int maxLen;
			for (Address cur = range.getMinAddress(); cur.compareTo(
				range.getMaxAddress()) <= 0; cur = cur.addNoWrap(maxLen)) {
				long offset = cur.getOffset();
				long roundOffset = offset & BLOCK_MASK;
				int srcOffset = (int) (offset - roundOffset);
				maxLen =
					(int) Math.min(BLOCK_SIZE - srcOffset, range.getMaxAddress().subtract(cur) + 1);
				OffsetSnap loc = new OffsetSnap(roundOffset, snap);
				if (doCheckBytesChanged(loc, srcOffset, maxLen, buf1, buf2)) {
					return true;
				}
			}
		}
		catch (AddressOverflowException e) {
			// exited loop
		}
		return false;
	}

	@Override
	public Long getSnapOfMostRecentChangeToBlock(long snap, Address address) {
		assertInSpace(address);
		try (LockHold _ = LockHold.lock(lock.readLock())) {
			long offset = address.getOffset();
			long roundOffset = offset & BLOCK_MASK;
			OffsetSnap loc = new OffsetSnap(roundOffset, snap);
			DBTraceMemoryBlockEntry ent = findMostRecentBlockEntry(loc, true);
			if (ent == null) {
				return null;
			}
			return ent.getSnap();
		}
	}

	@Override
	public int getBlockSize() {
		return BLOCK_SIZE;
	}

	protected boolean isCross(long lower, long upper) {
		return lower < 0 && upper >= 0;
	}

	/**
	 * Determine the truncation snap if the given span and range include byte changes
	 * 
	 * <p>
	 * Code units do not understand or accommodate changes in time, so the underlying bytes of the
	 * unit must be the same throughout its lifespan. Typically, units are placed with a desired
	 * creation snap, and then its life is extended into the future opportunistically. Thus, when
	 * truncating, we desire to keep the start snap, then search for the soonest byte change within
	 * the desired lifespan. Furthermore, we generally don't permit a unit to exist in both record
	 * and scratch spaces, i.e., it cannot span both the -1 and 0 snaps.
	 * 
	 * @param span the desired lifespan
	 * @param range the address range covered
	 * @return the first snap that should be excluded, or {@link Long#MIN_VALUE} to indicate no
	 *         change.
	 */
	public long getFirstChange(Lifespan span, AddressRange range) {
		assertInSpace(range);
		long lower = span.lmin();
		long upper = span.lmax();
		if (lower == upper) {
			return Long.MIN_VALUE;
		}
		boolean cross = isCross(lower, upper);
		if (cross && lower == -1) {
			return 0; // Avoid reversal of range end points. 
		}
		Lifespan fwdOne = Lifespan.span(lower + 1, cross ? -1 : upper);
		ByteBuffer buf1 = ByteBuffer.allocate(BLOCK_SIZE);
		ByteBuffer buf2 = ByteBuffer.allocate(BLOCK_SIZE);
		try (LockHold _ = LockHold.lock(lock.readLock())) {
			for (TraceAddressSnapRange tasr : stateMapSpace
					.reduce(TraceAddressSnapRangeQuery.leastRecent(range, fwdOne))
					.orderedKeys()) {
				AddressRange toExamine = range.intersect(tasr.getRange());
				if (doCheckBytesChanged(tasr.getY1(), toExamine, buf1, buf2)) {
					return tasr.getY1();
				}
			}
			return cross ? 0 : Long.MIN_VALUE;
		}
		catch (IOException e) {
			blockStore.dbError(e);
			return 0;
		}
	}

	@Override
	public void removeBytes(long snap, Address start, int len) {
		assertInSpace(start);
		/*
		 * TODO: This implementation could be more efficient, but I don't think it will be used
		 * often enough to justify optimization.
		 */
		if (len <= 0) {
			return;
		}
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			ByteBuffer oldBytes = ByteBuffer.allocate(len);
			getBytes(snap, start, oldBytes);
			// New in the sense that they're about to replace the old bytes
			ByteBuffer newBytes = ByteBuffer.allocate(len);
			// NB. Don't want to wrap to Long.MAX_VALUE, but also don't want to read from scratch
			if (snap != 0 && snap != Long.MIN_VALUE) {
				getBytes(snap - 1, start, newBytes);
				newBytes.flip();
			}
			OutSnap lastSnap = new OutSnap(snap);
			Set<TraceAddressSnapRange> changed = new HashSet<>();
			doPutBytes(snap, start, newBytes, lastSnap, changed);
			Address end = start.add(len - 1);
			doSetState(snap, start, end, TraceMemoryState.UNKNOWN);

			// Fire event
			trace.setChanged(new TraceChangeRecord<>(
				TraceEvents.BYTES_CHANGED, space, new ImmutableTraceAddressSnapRange(start,
					start.add(newBytes.position() - 1), snap, lastSnap.snap),
				oldBytes.array(), newBytes.array()));

			// Fixup affected code units
			DBTraceCodeSpace codeSpace = trace.getCodeManager().get(space, false);
			if (codeSpace != null) {
				codeSpace.bytesChanged(changed, snap, start, oldBytes, newBytes);
			}
		}
		catch (IOException e) {
			blockStore.dbError(e);
		}
	}

	private static List<Integer> withinBlockMatchOffsets(byte[] buf, byte[] pattern) {
		List<Integer> offsets = new ArrayList<>();
		byte firstByte = pattern[0];
		for (int off = 0; off < buf.length - pattern.length; off++) {
			if (buf[off] == firstByte &&
			    Arrays.mismatch(buf, off, off + pattern.length, pattern, 0, pattern.length) == -1) {
				offsets.add(off);
			}
		}
		return offsets;
	}

	private static List<Integer> partialUpperBoundaryMatchOffsets(byte[] buf, byte[] pattern) {
		List<Integer> offsets = new ArrayList<>();
		int startOffset = buf.length - Math.min(buf.length, pattern.length) + 1;
		byte firstByte = pattern[0];
		for (int off = startOffset; off < buf.length; off++) {
			int lengthToCheck = buf.length - off;
			if (buf[off] == firstByte &&
			    Arrays.mismatch(buf, off, off + lengthToCheck, pattern, 0, lengthToCheck) == -1) {
				offsets.add(off);
			}
		}
		return offsets;
	}

	private static List<TraceAddressSnapRange> coalesceLifespansAndPruneToExactSearch(int hitLength,
			Map<Address, List<Lifespan>> hits, AddressRange targetRange, Lifespan targetSpan) {
		hits.values().forEach(l -> l.sort(Comparator.comparing(Lifespan::lmin)));

		List<TraceAddressSnapRange> retHits = new ArrayList<>();

		for (Entry<Address, List<Lifespan>> entry : hits.entrySet()) {
			AddressRangeImpl range =
					new AddressRangeImpl(entry.getKey(), entry.getKey().add(hitLength));
			if (!targetRange.intersects(range.getMinAddress(), range.getMaxAddress())) {
				continue;
			}
			Lifespan accumulator = entry.getValue().getFirst();
			for (Lifespan lifespan : entry.getValue()) {
				if (accumulator != lifespan) {
					if (accumulator.intersects(lifespan) ||
					    accumulator.lmax() + 1 == lifespan.lmin()) {
						accumulator = accumulator.bound(lifespan);
					}
					else {
						retHits.add(new ImmutableTraceAddressSnapRange(range, accumulator));
						accumulator = lifespan;
					}
				}
			}
			ImmutableTraceAddressSnapRange snapRange =
					new ImmutableTraceAddressSnapRange(range, accumulator);
			if (!retHits.contains(snapRange)) {
				retHits.add(snapRange);
			}
		}

		return retHits.stream().filter(e -> e.getLifespan().intersects(targetSpan)).toList();
	}

	@Override
	public Collection<Entry<TraceAddressSnapRange, TraceMemoryState>> getStates(Lifespan span,
			AddressRange range) {
		assertInSpace(range);
		return doGetStates(span, range);
	}

	@Override
	public List<TraceAddressSnapRange> findBytesAcrossLifespan(Lifespan span, AddressRange range, byte[] pattern,
			TaskMonitor monitor) {
		assertInSpace(range);
		if (pattern.length == 0) {
			return List.of();
		}

		Map<Address, List<Lifespan>> hits = searchBytesByMemoryBlocks(range, pattern, monitor);

		return coalesceLifespansAndPruneToExactSearch(pattern.length, hits, range, span);
	}

	private Map<Address, List<Lifespan>> searchBytesByMemoryBlocks(AddressRange range,
			byte[] pattern, TaskMonitor monitor) {
		// Cheat a little to include a lower block in the case that the pattern crosses the lower
		// search boundary
		long minOffset = Math.max(range.getMinAddress().getUnsignedOffset() - pattern.length, 0);
		long maxOffset = range.getMaxAddress().getUnsignedOffset();
		long firstBlock = minOffset & BLOCK_MASK;
		long lastBlock = maxOffset & BLOCK_MASK;

		OffsetSnap lo = new OffsetSnap(firstBlock, Long.MIN_VALUE);
		OffsetSnap hi = new OffsetSnap(lastBlock, Long.MAX_VALUE);

		Map<Address, List<Lifespan>> hits = new HashMap<>();

		for (Entry<OffsetSnap, DBTraceMemoryBlockEntry> ent : blocksByOffset.sub(lo, true, hi,
				true).entries()) {
			if (monitor.isCancelled()) {
				return Map.of();
			}

			byte[] blockBuf = new byte[BLOCK_SIZE];
			try (var _ = LockHold.lock(lock.readLock())) {
				ent.getValue().getBytes(ByteBuffer.wrap(blockBuf), 0, BLOCK_SIZE);
			}
			catch (IOException e) {
				blockStore.dbError(e);
				continue;
			}
			Map<OffsetSnap, Lifespan> lifespanCache = new HashMap<>();
			patternSearchWithinBlock(pattern, ent, blockBuf, hits, lifespanCache);
			patternSearchSpanningBlocks(pattern, monitor, ent, blockBuf, hits, lifespanCache);
		}

		return hits;
	}

	private void patternSearchWithinBlock(byte[] pattern,
			Entry<OffsetSnap, DBTraceMemoryBlockEntry> ent, byte[] blockBuf,
			Map<Address, List<Lifespan>> hits, Map<OffsetSnap, Lifespan> lifespanCache) {
		for (int off : withinBlockMatchOffsets(blockBuf, pattern)) {
			Address address = toAddress(ent.getValue().getOffset() + off);
			hits.computeIfAbsent(address, e -> new ArrayList<>());
			hits.get(address).add(getLifespanOfBlock(ent.getKey(), lifespanCache));
		}
	}

	private void patternSearchSpanningBlocks(byte[] pattern, TaskMonitor monitor,
			Entry<OffsetSnap, DBTraceMemoryBlockEntry> ent, byte[] blockBuf,
			Map<Address, List<Lifespan>> hits, Map<OffsetSnap, Lifespan> lifespanCache) {
		int adjacentBlocksToCheck = (int) Math.ceil((double) pattern.length / BLOCK_SIZE) + 1;

		int leadingZeros = 0;
		for (byte b : pattern) {
			if (b != 0) {
				break;
			}
			leadingZeros++;
		}
		byte[] modifiedPattern = Arrays.copyOfRange(pattern, leadingZeros, pattern.length);

		// Check upper bounds if we hit a partial match
		for (int off : partialUpperBoundaryMatchOffsets(blockBuf, modifiedPattern)) {
			if (monitor.isCancelled()) {
				return;
			}
			List<Lifespan> adjacentBlocks =
					getIntersectingLifespansOfAdjacentBlocks(ent.getKey(), adjacentBlocksToCheck,
							null, lifespanCache);
			for (Lifespan lifespan : adjacentBlocks) {
				byte[] buf = new byte[pattern.length];
				getBytes(lifespan.lmin(),
						toAddress(ent.getValue().getOffset() + off - leadingZeros),
						ByteBuffer.wrap(buf));

				if (Arrays.mismatch(buf, pattern) == -1) {
					Address address = toAddress(ent.getValue().getOffset() + off - leadingZeros);
					hits.computeIfAbsent(address, e -> new ArrayList<>());
					hits.get(address).add(lifespan);
				}
			}
		}

		// Check lower bounds since we got leading 0s to deal with
		if (leadingZeros > 0 && !lowerMemoryBlockExists(ent.getKey())) {
			byte[] buf = new byte[pattern.length];
			getBytes(ent.getKey().snap, toAddress(ent.getValue().getOffset() - leadingZeros),
					ByteBuffer.wrap(buf));
			if (Arrays.mismatch(buf, pattern) == -1) {
				Address address = toAddress(ent.getValue().getOffset() - leadingZeros);
				hits.computeIfAbsent(address, e -> new ArrayList<>());
				hits.get(address).add(getLifespanOfBlock(ent.getKey(), lifespanCache));
			}
		}
	}

	private boolean lowerMemoryBlockExists(OffsetSnap offsetSnap) {
		OffsetSnap start = new OffsetSnap(offsetSnap.offset - BLOCK_SIZE, 0);
		OffsetSnap stop = new OffsetSnap(offsetSnap.offset - BLOCK_SIZE, Long.MAX_VALUE);
		return blocksByOffset.sub(start, true, stop, true).keys().iterator().hasNext();
	}

	private boolean upperMemoryBlockExists(OffsetSnap offsetSnap) {
		OffsetSnap start = new OffsetSnap(offsetSnap.offset + BLOCK_SIZE, 0);
		OffsetSnap stop = new OffsetSnap(offsetSnap.offset + BLOCK_SIZE, Long.MAX_VALUE);
		return blocksByOffset.sub(start, true, stop, true).keys().iterator().hasNext();
	}

	private Lifespan getLifespanOfBlock(OffsetSnap offsetSnap, Map<OffsetSnap, Lifespan> cache) {
		if (cache != null && cache.containsKey(offsetSnap)) {
			return cache.get(offsetSnap);
		}
		Lifespan lifespan;
		OffsetSnap nextOffsetSnap = blocksByOffset.higherKey(offsetSnap);
		if (nextOffsetSnap == null) {
			lifespan = Lifespan.nowOn(offsetSnap.snap);
		}
		else if (offsetSnap.offset == nextOffsetSnap.offset &&
		         offsetSnap.isScratch() == nextOffsetSnap.isScratch()) {
			lifespan = Lifespan.span(offsetSnap.snap, nextOffsetSnap.snap - 1);
		}
		else if (offsetSnap.isScratch()) {
			lifespan = Lifespan.at(offsetSnap.snap);
		}
		else {
			lifespan = Lifespan.nowOn(offsetSnap.snap);
		}
		if (cache != null) {
			cache.put(offsetSnap, lifespan);
		}
		return lifespan;
	}

	private List<Lifespan> getIntersectingLifespansOfAdjacentBlocks(OffsetSnap offsetSnap,
			int numberOfBlocks, Lifespan accumulatorSpan,
			Map<OffsetSnap, Lifespan> lifespanCache) {
		if (numberOfBlocks == 1) {
			return List.of(accumulatorSpan);
		}
		List<Lifespan> intersectingLifespans = new ArrayList<>();
		Lifespan curLifespan;
		if (accumulatorSpan != null) {
			curLifespan = accumulatorSpan;
		}
		else {
			curLifespan = getLifespanOfBlock(offsetSnap, lifespanCache);
		}

		if (upperMemoryBlockExists(offsetSnap)) {
			// Check all lifespans of next block for intersections
			OffsetSnap firstHit = null;
			OffsetSnap start = new OffsetSnap(offsetSnap.offset + BLOCK_SIZE, 0);
			OffsetSnap stop = new OffsetSnap(offsetSnap.offset + BLOCK_SIZE, Long.MAX_VALUE);
			for (OffsetSnap adjacentOffsetSnap : blocksByOffset.sub(start, true, stop, true)
					.keys()) {
				Lifespan intersected =
						getLifespanOfBlock(adjacentOffsetSnap, lifespanCache).intersect(
								curLifespan);
				if (firstHit == null) {
					firstHit = adjacentOffsetSnap;
				}
				if (!intersected.isEmpty()) {
					intersectingLifespans.addAll(
							getIntersectingLifespansOfAdjacentBlocks(adjacentOffsetSnap,
									numberOfBlocks - 1, intersected, lifespanCache));
				}
			}

			// Check if lifespan before block was initialized (i.e. when it was all 0s) intersects
			assert firstHit != null;
			Lifespan intersected = Lifespan.before(firstHit.snap).intersect(curLifespan);
			if (!intersected.isEmpty()) {
				intersectingLifespans.addAll(getIntersectingLifespansOfAdjacentBlocks(
						new OffsetSnap(firstHit.offset, Long.MIN_VALUE), numberOfBlocks - 1,
						intersected, lifespanCache));
			}
		}
		else {
			// Upper block was never touched so just return same lifespan
			intersectingLifespans.add(curLifespan);
		}
		return intersectingLifespans;
	}

	@Override
	public MemBuffer getBufferAt(long snap, Address start, ByteOrder byteOrder) {
		return new DBTraceMemBuffer(this, snap, start, byteOrder);
	}

	@Override
	public void pack() {
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			// TODO: Check and rearrange blocks chronologically
			// TODO: Remove identical, adjacent future blocks
			for (DBTraceMemoryBufferEntry bufEnt : bufferStore.asMap().values()) {
				bufEnt.compress();
			}
		}
		catch (IOException e) {
			bufferStore.dbError(e);
		}
	}

	@Override
	public void invalidateCache() {
		try (LockHold _ = LockHold.lock(lock.writeLock())) {
			trace.updateViewsRefreshBlocks();
			trace.updateViewsBytesChanged(null);
			stateMapSpace.invalidateCache();
			bufferStore.invalidateCache();
			blockStore.invalidateCache();
			blockCacheMostRecent.clear();
			addressSetStateCache.clear();
			mostRecentStateEntryCache.clear();
		}
	}

	/**
	 * For developers and testers.
	 * 
	 * @param painter painter
	 * @param depth depth
	 */
	@Internal
	public void paint(Painter painter, int depth) {
		stateMapSpace.paint(painter, depth);
	}

	/**
	 * For developers and testers.
	 * 
	 * @return depth
	 */
	@Internal
	public int getDepth() {
		return stateMapSpace.getDepth();
	}

	/**
	 * For developers and testers.
	 * 
	 * @return root bounds
	 */
	@Internal
	public TraceAddressSnapRange getRootBounds() {
		return stateMapSpace.getRootBounds();
	}

	/**
	 * For developers and testers.
	 * 
	 * @param rec record
	 * @return children
	 */
	@Internal
	public Collection<? extends DBTreeRecord<?, ? extends TraceAddressSnapRange>>
			getChildrenOf(DBTreeNodeRecord<?> rec) {
		return stateMapSpace.getChildrenOf(rec);
	}
}
