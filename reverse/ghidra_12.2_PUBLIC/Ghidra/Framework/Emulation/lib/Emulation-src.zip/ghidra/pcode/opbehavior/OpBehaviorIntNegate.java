/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.pcode.opbehavior;

import java.math.BigInteger;

import ghidra.pcode.utils.Utils;
import ghidra.program.model.pcode.PcodeOp;
import ghidra.util.exception.AssertException;

public enum OpBehaviorIntNegate implements UnaryOpBehavior {
	OP_INT_NEGATE;

	@Override
	public int opcode() {
		return PcodeOp.INT_NEGATE;
	}

	@Override
	public long evaluateUnary(int sizeout, int sizein, long in1) {
		long res = Utils.uintb_negate(in1, sizein);
		return res;
	}

	@Override
	public BigInteger evaluateUnary(int sizeout, int sizein, BigInteger in1) {
		if (in1.signum() < 0) {
			throw new AssertException("Expected unsigned in value");
		}
		return in1.not();
	}
}
