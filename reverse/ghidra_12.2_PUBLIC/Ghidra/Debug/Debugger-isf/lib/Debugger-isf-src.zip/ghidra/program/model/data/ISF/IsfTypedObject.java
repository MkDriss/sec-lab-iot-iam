/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.program.model.data.ISF;

import ghidra.program.model.data.DataType;

public class IsfTypedObject extends AbstractIsfObject {

	public String kind;
	public Integer size;
	public IsfObject type;

	public IsfTypedObject(DataType dt, IsfObject typeObj) {
		super(dt);
		kind = IsfUtilities.getKind(dt);
		size = dt.hasLanguageDependantLength() ? -1 : dt.getLength();
		type = typeObj;
	}

}
