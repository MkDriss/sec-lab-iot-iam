/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.app.plugin.core.decompiler.export;

/**
 * Describes the per-data-type methods for reading for XML attributes and elements via the decoder
 */

public enum DecoderMethods {

	READ_BOOL,
	READ_SINT,
	READ_UINT,
	READ_STRING,
	READ_SPACE,
	READ_OPCODE,

	READ_UNKNOWN;

}
