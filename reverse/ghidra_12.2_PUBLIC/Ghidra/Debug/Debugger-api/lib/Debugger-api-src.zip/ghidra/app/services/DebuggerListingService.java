/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.app.services;

import java.util.List;

import ghidra.app.util.viewer.listingpanel.ListingPanel;
import ghidra.debug.api.action.AutoReadMemorySpec;
import ghidra.debug.api.action.LocationTrackingSpec;
import ghidra.debug.api.listing.DebuggerListing;
import ghidra.debug.api.listing.MultiBlendedListingBackgroundColorModel;
import ghidra.framework.plugintool.ServiceInfo;
import ghidra.pcode.exec.SleighUtils.LitIdMode;
import ghidra.program.model.address.Address;
import ghidra.program.util.ProgramSelection;

/**
 * A service providing access to the main listing panel
 */
@ServiceInfo(
	defaultProviderName = "ghidra.app.plugin.core.debug.gui.listing.DebuggerListingPlugin",
	description = "Replacement CodeViewerService for Debugger")
public interface DebuggerListingService extends CodeViewerService {

	/**
	 * A listener for changes in location tracking specification
	 */
	interface LocationTrackingSpecChangeListener {
		/**
		 * The specification has changed
		 * 
		 * @param spec the new specification
		 */
		void locationTrackingSpecChanged(LocationTrackingSpec spec);
	}

	/**
	 * Set the tracking specification of the listing. Navigates immediately.
	 * 
	 * @param spec the desired specification
	 */
	void setTrackingSpec(LocationTrackingSpec spec);

	/**
	 * Get the tracking specification of the main listing.
	 * 
	 * @return the current specification
	 */
	LocationTrackingSpec getTrackingSpec();

	/**
	 * Create a new disconnected debugger listing
	 *
	 * @return newly created debugger listing
	 */
	DebuggerListing createNewListing();

	/**
	 * Get all debugger listings
	 *
	 * @return List of all debugger listings
	 */
	List<DebuggerListing> getAllListings();

	/**
	 * Get the auto-read memory specification of the main listing.
	 * 
	 * @return the current specification
	 */
	AutoReadMemorySpec getAutoReadMemorySpec();

	/**
	 * Add a listener for changes to the tracking specification.
	 * 
	 * @param listener the listener to receive change notifications
	 */
	void addTrackingSpecChangeListener(LocationTrackingSpecChangeListener listener);

	/**
	 * Remove a listener for changes to the tracking specification.
	 * 
	 * @param listener the listener receiving change notifications
	 */
	void removeTrackingSpecChangeListener(LocationTrackingSpecChangeListener listener);

	/**
	 * Set the selection of addresses in this listing.
	 * 
	 * @param selection the desired selection
	 */
	void setCurrentSelection(ProgramSelection selection);

	/**
	 * Navigate to the given address
	 * 
	 * @param address the desired address
	 * @param centerOnScreen true to center the cursor in the listing
	 * @return true if the request was effective
	 */
	boolean goTo(Address address, boolean centerOnScreen);

	/**
	 * Set the mode of the Go-to dialog's Sleigh expressions
	 * <p>
	 * This applies to all Go-to dialogs among the dynamic providers, including listings and memory
	 * (hex byte) views.
	 * 
	 * @param mode the new mode
	 */
	void setGoToSleighMode(LitIdMode mode);

	/**
	 * Get the mode of the Go-to dialog's Sleigh expressions
	 * 
	 * @return the current mode
	 */
	LitIdMode getGoToSleighMode();

	/**
	 * Obtain a coloring background model suitable for the given listing
	 * 
	 * <p>
	 * This may be used, e.g., to style an alternative view in the same manner as listings managed
	 * by this service. Namely, this provides coloring for memory state and the user's cursor.
	 * Coloring for tracked locations and the marker service in general must still be added
	 * separately, since they incorporate additional dependencies.
	 * 
	 * @param listingPanel the panel to be colored
	 * @return a blended background color model implementing the common debugger listing style
	 */
	MultiBlendedListingBackgroundColorModel createListingBackgroundColorModel(
			ListingPanel listingPanel);

	/**
	 * Get the next custom title for a DebuggerListing
	 *
	 * @return Next custom title
	 */
	String findNextCustomTitle();
}
