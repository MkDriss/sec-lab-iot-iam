/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.app.plugin.core.debug.disassemble;

import docking.action.MenuData;
import ghidra.app.plugin.core.assembler.AbstractPatchAction;
import ghidra.program.model.address.Address;
import ghidra.program.model.lang.*;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.Program;
import ghidra.trace.model.guest.TracePlatform;
import ghidra.trace.model.listing.TraceInstruction;
import ghidra.trace.model.program.TraceProgramView;

public class FixedPlatformTraceAssemblePatchAction extends AbstractTraceAssemblePatchAction {

	private final LanguageID altLangID;
	private final TracePlatform platform;

	public FixedPlatformTraceAssemblePatchAction(DebuggerDisassemblerPlugin plugin,
			LanguageID altLangID, TracePlatform platform) {
		this.altLangID = altLangID;
		this.platform = platform;
		super(plugin, "Assemble using " + altLangID);
	}

	@Override
	protected MenuData createMenuData(String name) {
		MenuData menuData =
			new MenuData(new String[] { "Assemble using...", altLangID.toString() });
		menuData.setParentMenuGroup(AbstractPatchAction.MENU_GROUP);
		return menuData;
	}

	@Override
	protected TracePlatform getPlatform(TraceProgramView view, Address entry) {
		return platform;
	}

	@Override
	protected RegisterValue getInitialContext(Instruction ins, Program program, Address entry) {
		Language language = ins instanceof TraceInstruction tins
				? tins.getLanguage()
				: program.getLanguage();
		return DebuggerDisassemblerPlugin.deriveAlternativeDefaultContext(language, altLangID,
			entry);
	}
}
